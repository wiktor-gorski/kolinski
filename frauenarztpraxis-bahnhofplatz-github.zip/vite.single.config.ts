import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// Erzeugt eine einzelne, eigenständige HTML-Datei zum lokalen Öffnen im Browser.
export default defineConfig({
  plugins: [react(), viteSingleFile()],
  base: './',
  publicDir: false,
  build: { outDir: 'vorschau', assetsInlineLimit: 100_000_000, cssCodeSplit: false },
});
