import { MotionConfig } from 'framer-motion';
import { useEffect, useState } from 'react';
import { Booking } from './components/Booking';
import { Doctor } from './components/Doctor';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Datenschutz, Impressum } from './components/Legal';
import { LifeJourney } from './components/LifeJourney';
import { Location } from './components/Location';
import { MobileBar } from './components/MobileBar';
import { Practice } from './components/Practice';
import { Services } from './components/Services';
import { Statement } from './components/Statement';
import { Trust } from './components/Trust';

type Route = 'home' | 'impressum' | 'datenschutz';

function readRoute(): Route {
  const h = window.location.hash;
  if (h.startsWith('#/impressum')) return 'impressum';
  if (h.startsWith('#/datenschutz')) return 'datenschutz';
  return 'home';
}

export default function App() {
  const [route, setRoute] = useState<Route>(readRoute);

  useEffect(() => {
    const onHash = () => setRoute(readRoute());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  // Nach Rückkehr von einer Unterseite zum gewünschten Anker springen
  useEffect(() => {
    if (route !== 'home') return;
    const id = window.location.hash.slice(1);
    if (id && !id.startsWith('/')) {
      requestAnimationFrame(() => document.getElementById(id)?.scrollIntoView());
    }
  }, [route]);

  const onHome = route === 'home';

  return (
    <MotionConfig reducedMotion="user">
      <a className="skip-link" href="#main">
        Zum Inhalt springen
      </a>
      <Header onHome={onHome} />
      <main id="main" tabIndex={-1}>
        {route === 'home' && (
          <>
            <Hero />
            <Statement />
            <Doctor />
            <LifeJourney />
            <Services />
            <Trust />
            <Practice />
            <Booking />
            <Location />
          </>
        )}
        {route === 'impressum' && <Impressum />}
        {route === 'datenschutz' && <Datenschutz />}
      </main>
      <Footer onHome={onHome} />
      {onHome && <MobileBar />}
    </MotionConfig>
  );
}
