import { motion, useReducedMotion, useScroll, useTransform, type MotionStyle, type MotionValue } from 'framer-motion';
import { useRef, type ReactNode, type CSSProperties, type ElementType } from 'react';

export const EASE = [0.22, 1, 0.36, 1] as const;
export const EASE_SOFT = [0.65, 0, 0.35, 1] as const;

/** Sanftes Einblenden beim Eintritt in den Viewport. */
export function Reveal({
  children,
  delay = 0,
  y = 28,
  as = 'div',
  className,
  style,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  as?: 'div' | 'p' | 'li' | 'span' | 'h2' | 'h3' | 'section' | 'ul' | 'dl';
  className?: string;
  style?: CSSProperties;
}) {
  const reduce = useReducedMotion();
  const Comp = motion[as] as ElementType;
  return (
    <Comp
      className={className}
      style={style}
      initial={{ opacity: 0, y: reduce ? 0 : y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '0px 0px -10% 0px' }}
      transition={{ duration: reduce ? 0.3 : 1.1, delay, ease: EASE }}
    >
      {children}
    </Comp>
  );
}

/**
 * Zeilenweiser Mask-Reveal für Editorial-Headlines.
 * Beobachtet wird die (nicht verschobene) Maske selbst – so greift der Reveal zuverlässig.
 */
export function MaskLines({
  lines,
  delay = 0,
  stagger = 0.12,
  inView = true,
  className,
}: {
  lines: ReactNode[];
  delay?: number;
  stagger?: number;
  inView?: boolean;
  className?: string;
}) {
  const reduce = useReducedMotion();
  return (
    <>
      {lines.map((line, i) => (
        <motion.span
          className={`mask-line ${className ?? ''}`}
          key={i}
          initial="hidden"
          {...(inView
            ? { whileInView: 'show', viewport: { once: true, margin: '0px 0px -6% 0px' } }
            : { animate: 'show' })}
        >
          <motion.span
            className="mask-line__inner"
            variants={{
              hidden: { y: reduce ? 0 : '108%', opacity: reduce ? 0 : 1 },
              show: {
                y: '0%',
                opacity: 1,
                transition: { duration: reduce ? 0.4 : 1.25, delay: delay + i * stagger, ease: EASE },
              },
            }}
          >
            {line}
          </motion.span>
        </motion.span>
      ))}
    </>
  );
}

/** Organische Linie, die sich beim Eintritt (oder scrollgekoppelt) selbst zeichnet. */
export function DrawPath({
  d,
  progress,
  duration = 2.4,
  delay = 0,
  className,
  strokeWidth = 1,
  immediate = false,
}: {
  d: string;
  progress?: MotionValue<number>;
  duration?: number;
  delay?: number;
  className?: string;
  strokeWidth?: number;
  immediate?: boolean;
}) {
  const reduce = useReducedMotion();
  const common = {
    d,
    className,
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    vectorEffect: 'non-scaling-stroke' as const,
  };
  if (reduce) return <path {...common} />;
  if (progress) return <motion.path {...common} style={{ pathLength: progress }} />;
  const anim = { pathLength: 1, opacity: 1 } as never;
  return (
    <motion.path
      {...common}
      initial={{ pathLength: 0, opacity: 0 } as never}
      {...(immediate ? { animate: anim } : { whileInView: anim, viewport: { once: true, margin: '0px 0px -12% 0px' } })}
      transition={{
        pathLength: { duration, delay, ease: EASE_SOFT },
        opacity: { duration: 0.4, delay },
      }}
    />
  );
}

/** Mehrere Pfade nacheinander zeichnen. */
export function DrawMotif({
  paths,
  viewBox = '0 0 400 500',
  className,
  delay = 0,
  stagger = 0.18,
  duration = 2,
  immediate = false,
  label,
}: {
  paths: string[];
  viewBox?: string;
  className?: string;
  delay?: number;
  stagger?: number;
  duration?: number;
  immediate?: boolean;
  label?: string;
}) {
  return (
    <svg
      viewBox={viewBox}
      className={className}
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      focusable="false"
    >
      {paths.map((d, i) => (
        <DrawPath key={i} d={d} delay={delay + i * stagger} duration={duration} immediate={immediate} />
      ))}
    </svg>
  );
}

/** Bildreveal über Clip-Path mit minimaler Skalierung. */
export function MaskReveal({
  children,
  className,
  delay = 0,
  from = 'bottom',
  immediate = false,
  style,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  from?: 'bottom' | 'left' | 'right' | 'top';
  immediate?: boolean;
  style?: CSSProperties;
}) {
  const reduce = useReducedMotion();
  const start = {
    bottom: 'inset(100% 0% 0% 0%)',
    top: 'inset(0% 0% 100% 0%)',
    left: 'inset(0% 100% 0% 0%)',
    right: 'inset(0% 0% 0% 100%)',
  }[from];
  const target = { clipPath: 'inset(0% 0% 0% 0%)', opacity: 1 };
  return (
    <motion.div
      className={className}
      style={style as MotionStyle}
      initial={reduce ? { opacity: 0 } : { clipPath: start }}
      {...(immediate ? { animate: target } : { whileInView: target, viewport: { once: true, margin: '0px 0px -10% 0px' } })}
      transition={{ duration: reduce ? 0.5 : 1.6, delay, ease: EASE }}
    >
      <motion.div
        className="mask-reveal__scale"
        initial={{ scale: reduce ? 1 : 1.12 }}
        {...(immediate ? { animate: { scale: 1 } } : { whileInView: { scale: 1 }, viewport: { once: true } })}
        transition={{ duration: reduce ? 0 : 2.2, delay, ease: EASE }}
      >
        {children}
      </motion.div>
    </motion.div>
  );
}

/** Dezenter Parallax-Versatz. */
export function Parallax({
  children,
  amount = 60,
  className,
  style,
}: {
  children: ReactNode;
  amount?: number;
  className?: string;
  style?: CSSProperties;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], [amount, -amount]);
  return (
    <motion.div ref={ref} className={className} style={{ ...(style as MotionStyle), y: reduce ? 0 : y }}>
      {children}
    </motion.div>
  );
}

/** Langsam atmende organische Hintergrundform (reines CSS-Keyframe, GPU-freundlich). */
export function Breath({ className, style }: { className?: string; style?: CSSProperties }) {
  return <span aria-hidden="true" className={`breath ${className ?? ''}`} style={style} />;
}

export function Arrow({ className }: { className?: string }) {
  return (
    <svg className={`arrow ${className ?? ''}`} viewBox="0 0 24 12" aria-hidden="true" focusable="false">
      <path d="M0 6h22M17 1l5 5-5 5" fill="none" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}

export function ExternalHint() {
  return <span className="sr-only"> (öffnet externe Website in neuem Tab)</span>;
}
