import { SIGNATURE_LINE } from '../art/paths';
import { PRACTICE } from '../data/practice';
import { OpeningHours } from './Location';
import { DrawPath, ExternalHint } from './motion';

export function Footer({ onHome }: { onHome: boolean }) {
  const home = onHome ? '' : '';
  return (
    <footer className="footer">
      <svg className="footer__line" viewBox="0 0 1440 240" preserveAspectRatio="none" aria-hidden="true">
        <DrawPath d={SIGNATURE_LINE} duration={3.4} strokeWidth={1.1} />
      </svg>

      <div className="container">
        <p className="footer__mark">
          Frauenarztpraxis <em>Bahnhofplatz</em>
        </p>

        <div className="footer__grid">
          <div>
            <h2 className="footer__k">Ärztin</h2>
            <p>
              {PRACTICE.doctor}
              <br />
              {PRACTICE.title}
            </p>
          </div>
          <div>
            <h2 className="footer__k">Adresse</h2>
            <address>
              {PRACTICE.street}
              <br />
              {PRACTICE.zip} {PRACTICE.city}
              <br />
              3. Obergeschoss, Eingang beim Visilab
            </address>
          </div>
          <div>
            <h2 className="footer__k">Kontakt</h2>
            <p>
              <a className="link-underline" href={PRACTICE.phoneHref}>
                {PRACTICE.phoneDisplay}
              </a>
              <br />
              <a className="link-underline" href={`mailto:${PRACTICE.email}`}>
                {PRACTICE.email}
              </a>
              <br />
              <a className="link-underline" href={PRACTICE.booking} target="_blank" rel="noopener">
                Online-Terminbuchung
                <ExternalHint />
              </a>
            </p>
          </div>
          <div>
            <h2 className="footer__k">Öffnungszeiten</h2>
            <OpeningHours compact />
          </div>
        </div>

        <div className="footer__bottom">
          <p>
            © {new Date().getFullYear()} {PRACTICE.name}
          </p>
          <nav aria-label="Rechtliches">
            <a className="link-underline" href="#/impressum">
              Impressum
            </a>
            <a className="link-underline" href="#/datenschutz">
              Datenschutz
            </a>
            <a className="link-underline" href={`${home}#start`}>
              Nach oben
            </a>
          </nav>
        </div>
      </div>
    </footer>
  );
}
