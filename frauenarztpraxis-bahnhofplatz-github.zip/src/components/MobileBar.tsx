import { AnimatePresence, motion, useMotionValueEvent, useScroll } from 'framer-motion';
import { useState } from 'react';
import { PRACTICE } from '../data/practice';
import { EASE, ExternalHint } from './motion';

/** Dezente mobile Sticky-Leiste – erscheint nach dem Hero. */
export function MobileBar() {
  const { scrollY } = useScroll();
  const [show, setShow] = useState(false);
  useMotionValueEvent(scrollY, 'change', (v) => setShow(v > window.innerHeight * 0.6));

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="mobile-bar"
          initial={{ y: '110%' }}
          animate={{ y: 0 }}
          exit={{ y: '110%' }}
          transition={{ duration: 0.6, ease: EASE }}
        >
          <a className="mobile-bar__call" href={PRACTICE.phoneHref}>
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path
                d="M6.6 3.5h2.6l1.4 4.2-2 1.4a12 12 0 0 0 6.3 6.3l1.4-2 4.2 1.4v2.6a2 2 0 0 1-2.2 2C10.6 18.9 5.1 13.4 4.6 5.7a2 2 0 0 1 2-2.2Z"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.3"
              />
            </svg>
            Anrufen
          </a>
          <a className="mobile-bar__book" href={PRACTICE.booking} target="_blank" rel="noopener">
            Termin buchen
            <ExternalHint />
          </a>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
