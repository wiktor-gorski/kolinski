import { animate, useInView, useReducedMotion } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import { PRACTICE } from '../data/practice';
import { Arrow, DrawPath, ExternalHint, MaskLines, Reveal } from './motion';

function CountUp({ to }: { to: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '0px 0px -15% 0px' });
  const reduce = useReducedMotion();
  const [val, setVal] = useState(reduce ? to : 0);
  useEffect(() => {
    if (!inView || reduce) return;
    const c = animate(0, to, { duration: 2.2, ease: [0.22, 1, 0.36, 1], onUpdate: (v) => setVal(Math.round(v)) });
    return () => c.stop();
  }, [inView, to, reduce]);
  return (
    <span ref={ref} aria-hidden="true">
      {val}
    </span>
  );
}

export function Trust() {
  return (
    <section className="trust section" aria-labelledby="trust-title">
      <div className="container trust__grid">
        <div className="trust__figure">
          <svg className="trust__ring" viewBox="0 0 400 400" aria-hidden="true">
            <DrawPath
              d="M200,30 C320,28 380,120 372,210 C364,310 280,376 190,370 C96,364 26,290 32,196 C38,104 110,40 210,44"
              duration={3}
            />
          </svg>
          <p className="trust__number">
            <span className="trust__more">mehr als</span>
            <span className="trust__digits">
              <CountUp to={330} />
              <span className="sr-only">330</span>
            </span>
            <span className="trust__unit">Empfehlungen auf Doctena</span>
          </p>
        </div>

        <div className="trust__content">
          <Reveal as="p" className="eyebrow">Patientenfeedback</Reveal>
          <h2 id="trust-title" className="display display--md">
            <MaskLines lines={['Vertrauen entsteht', <em key="i">durch persönliche Erfahrungen.</em>]} />
          </h2>
          <Reveal as="p" className="lead" delay={0.1}>
            Auf dem Doctena-Profil der Praxis haben Patientinnen ihre Erfahrungen geteilt. Lesen Sie die Rückmeldungen
            direkt an der Quelle – unverändert und im Original.
          </Reveal>
          <Reveal delay={0.2}>
            <a className="btn btn--outline" href={PRACTICE.booking} target="_blank" rel="noopener">
              <span>Patientenfeedback auf Doctena ansehen</span>
              <Arrow />
              <ExternalHint />
            </a>
          </Reveal>
          <Reveal as="p" className="fineprint" delay={0.25}>
            Angabe gemäss öffentlichem Doctena-Profil der Praxis.
          </Reveal>
        </div>
      </div>
    </section>
  );
}
