import { ArtPanel } from '../art/ArtPanel';
import { PRACTICE } from '../data/practice';
import { Arrow, ExternalHint, MaskLines, MaskReveal, Parallax, Reveal } from './motion';

const QUALIFICATIONS = [
  { key: 'FMH', label: 'Fachärztin FMH', detail: 'für Gynäkologie und Geburtshilfe' },
  { key: 'SGUM', label: 'Schwangerschaftsultraschall', detail: 'Schweizerische Gesellschaft für Ultraschall in der Medizin' },
  { key: 'KHM', label: 'Praxislabor', detail: 'Kollegium für Hausarztmedizin' },
  { key: '1980', label: 'Fachärztliche Ausrichtung', detail: 'seit 1980, gemäss veröffentlichtem Arztprofil' },
  { key: 'DE · PL', label: 'Sprachen', detail: 'Behandlung auf Deutsch und Polnisch' },
];

export function Doctor() {
  return (
    <section id="aerztin" className="doctor section" aria-labelledby="doctor-title">
      <div className="container doctor__grid">
        <div className="doctor__visual">
          <Parallax amount={30}>
            <MaskReveal className="doctor__portrait">
              <ArtPanel tone="dusk" placeholder="Bildplatz · Portrait nach Freigabe">
                <span className="doctor__monogram" aria-hidden="true">
                  J<em>K</em>
                </span>
              </ArtPanel>
            </MaskReveal>
          </Parallax>
          <Reveal as="p" className="doctor__vertical" delay={0.3}>
            Gynäkologie <span aria-hidden="true">—</span> Geburtshilfe
          </Reveal>
        </div>

        <div className="doctor__content">
          <Reveal as="p" className="eyebrow">Über die Ärztin</Reveal>
          <h2 id="doctor-title" className="display display--md">
            <MaskLines lines={['Medizinische Erfahrung.', <em key="i">Menschliche Nähe.</em>]} />
          </h2>

          <Reveal className="doctor__intro">
            <p className="lead">
              {PRACTICE.doctor} ist {PRACTICE.title} und begleitet Frauen seit vielen Jahren in ihrer Praxis am
              Bahnhofplatz in Zürich.
            </p>
            <p>
              Im Mittelpunkt steht eine individuelle Betreuung: Ihre persönlichen Anliegen werden ernst genommen,
              Befunde und Möglichkeiten verständlich erklärt – und für Ihre Fragen bleibt ausreichend Zeit.
            </p>
          </Reveal>

          <dl className="quals">
            {QUALIFICATIONS.map((q, i) => (
              <Reveal key={q.key} className="quals__row" delay={i * 0.08}>
                <dt className="quals__key">{q.key}</dt>
                <dd>
                  <span className="quals__label">{q.label}</span>
                  <span className="quals__detail">{q.detail}</span>
                </dd>
              </Reveal>
            ))}
          </dl>

          <Reveal delay={0.2}>
            <a className="btn btn--primary" href={PRACTICE.booking} target="_blank" rel="noopener">
              <span>Termin vereinbaren</span>
              <Arrow />
              <ExternalHint />
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
