import { ArtPanel, type Tone } from '../art/ArtPanel';
import { PRACTICE } from '../data/practice';
import { MaskLines, MaskReveal, Parallax, Reveal } from './motion';

const GALLERY: { tone: Tone; motif?: number; cls: string; from: 'bottom' | 'left' | 'right'; amount: number }[] = [
  { tone: 'sand', cls: 'g1', from: 'bottom', amount: 30 },
  { tone: 'rose', motif: 1, cls: 'g2', from: 'right', amount: 60 },
  { tone: 'ivory', cls: 'g3', from: 'left', amount: 20 },
  { tone: 'dusk', cls: 'g4', from: 'bottom', amount: 45 },
];

const FACTS = [
  { big: '01', label: 'Drittes Obergeschoss', text: 'Die Praxis befindet sich im dritten Stock.' },
  { big: '02', label: 'Lift oder Treppe', text: 'Der Zugang ist über den Lift oder das Treppenhaus möglich.' },
  { big: '03', label: 'Eingang beim Visilab', text: 'Der Hauseingang liegt beim Visilab am Bahnhofplatz 4.' },
  { big: '04', label: 'Gegenüber dem Hauptbahnhof', text: 'Direkt gegenüber dem Hauptbahnhof Zürich.' },
];

export function Practice() {
  return (
    <section id="praxis" className="practice section" aria-labelledby="practice-title">
      <div className="container">
        <div className="practice__head">
          <Reveal as="p" className="eyebrow">Die Praxis</Reveal>
          <h2 id="practice-title" className="display display--md">
            <MaskLines lines={['Ein Ort, an dem Sie sich', <em key="i">wohlfühlen dürfen.</em>]} />
          </h2>
          <Reveal as="p" className="practice__intro" delay={0.15}>
            Mitten in Zürich, direkt gegenüber dem Hauptbahnhof – und doch ein Ort, an dem Sie in Ruhe ankommen und
            sich Zeit für Ihre Anliegen nehmen dürfen. Die Praxis am {PRACTICE.street} ist zentral und unkompliziert
            erreichbar.
          </Reveal>
        </div>

        <div className="gallery">
          {GALLERY.map((g, i) => (
            <Parallax key={g.cls} className={`gallery__item gallery__item--${g.cls}`} amount={g.amount}>
              <MaskReveal from={g.from} delay={i * 0.1}>
                <ArtPanel
                  tone={g.tone}
                  motif={g.motif}
                  placeholder={`Bildplatz ${String(i + 1).padStart(2, '0')} · Praxisaufnahme nach Freigabe`}
                />
              </MaskReveal>
            </Parallax>
          ))}
        </div>

        <ul className="facts" aria-label="Zugang zur Praxis">
          {FACTS.map((f, i) => (
            <Reveal as="li" key={f.label} className="facts__item" delay={i * 0.08}>
              <span className="facts__big" aria-hidden="true">
                {f.big}
              </span>
              <span className="facts__label">{f.label}</span>
              <span className="facts__text">{f.text}</span>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
