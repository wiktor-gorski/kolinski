import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { useId, useState } from 'react';
import { MOTIFS } from '../art/paths';
import { SERVICES } from '../data/practice';
import { DrawMotif, EASE, MaskLines, Reveal } from './motion';

export function Services() {
  const [open, setOpen] = useState<number | null>(0);
  const reduce = useReducedMotion();
  const baseId = useId();

  return (
    <section id="leistungen" className="services section" aria-labelledby="services-title">
      <div className="container">
        <div className="services__head">
          <Reveal as="p" className="eyebrow">Leistungen</Reveal>
          <h2 id="services-title" className="display display--md">
            <MaskLines lines={['Kompetente Begleitung', <em key="i">für Ihre Gesundheit.</em>]} />
          </h2>
          <Reveal as="p" className="services__intro" delay={0.15}>
            Das Leistungsspektrum der Praxis im Überblick. Welche Untersuchung oder Beratung für Sie sinnvoll ist,
            besprechen Sie individuell im persönlichen Gespräch.
          </Reveal>
        </div>

        <ul className="acc">
          {SERVICES.map((s, i) => {
            const isOpen = open === i;
            const panelId = `${baseId}-panel-${i}`;
            const btnId = `${baseId}-btn-${i}`;
            return (
              <Reveal as="li" key={s.title} className={`acc__item ${isOpen ? 'is-open' : ''}`} delay={i * 0.06}>
                <h3 className="acc__heading">
                  <button
                    id={btnId}
                    type="button"
                    className="acc__trigger"
                    aria-expanded={isOpen}
                    aria-controls={panelId}
                    onClick={() => setOpen(isOpen ? null : i)}
                  >
                    <span className="acc__no">0{i + 1}</span>
                    <span className="acc__title">
                      {s.title} {s.italic && <em>{s.italic}</em>}
                    </span>
                    <span className="acc__count">{s.items.length} Leistungen</span>
                    <span className="acc__icon" aria-hidden="true" />
                  </button>
                </h3>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={panelId}
                      role="region"
                      aria-labelledby={btnId}
                      className="acc__panel"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: reduce ? 0 : 0.7, ease: EASE }}
                    >
                      <div className="acc__content">
                        <p className="acc__intro">{s.intro}</p>
                        <ul className="acc__list">
                          {s.items.map((it, k) => (
                            <motion.li
                              key={it}
                              initial={{ opacity: 0, x: reduce ? 0 : -12 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: 0.12 + k * 0.05, duration: 0.6, ease: EASE }}
                            >
                              {it}
                            </motion.li>
                          ))}
                        </ul>
                        <div className="acc__art" aria-hidden="true">
                          <DrawMotif paths={MOTIFS[s.art]} immediate delay={0.2} stagger={0.12} duration={1.6} />
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
                {/* Für Suchmaschinen und Nutzerinnen ohne JS-Interaktion: vollständige Liste */}
                {!isOpen && (
                  <ul className="sr-only">
                    {s.items.map((it) => (
                      <li key={it}>{it}</li>
                    ))}
                  </ul>
                )}
              </Reveal>
            );
          })}
        </ul>

        <Reveal className="services__note">
          <span className="services__note-mark" aria-hidden="true" />
          <p>
            Bei Geburten und Operationen kann die Ärztin Patientinnen auf Wunsch an öffentliche oder private Kliniken
            anmelden.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
