import { useEffect, type ReactNode } from 'react';
import { PRACTICE } from '../data/practice';
import { MaskLines, Reveal } from './motion';

/** Markierung für Angaben, die vor Veröffentlichung von der Praxis bestätigt/ergänzt werden müssen. */
function Todo({ children }: { children: ReactNode }) {
  return (
    <mark className="todo">
      <span className="todo__tag">Zur Prüfung</span> {children}
    </mark>
  );
}

function LegalShell({
  title,
  italic,
  meta,
  children,
}: {
  title: string;
  italic: string;
  meta: { title: string; description: string };
  children: ReactNode;
}) {
  useEffect(() => {
    const prevTitle = document.title;
    const desc = document.querySelector('meta[name="description"]');
    const prevDesc = desc?.getAttribute('content') ?? '';
    document.title = meta.title;
    desc?.setAttribute('content', meta.description);
    window.scrollTo(0, 0);
    document.getElementById('main')?.focus();
    return () => {
      document.title = prevTitle;
      desc?.setAttribute('content', prevDesc);
    };
  }, [meta.title, meta.description]);

  return (
    <article className="legal container">
      <p className="eyebrow">Entwurf · interne Prüfung</p>
      <h1 className="display display--md">
        <MaskLines inView={false} lines={[title, <em key="i">{italic}</em>]} />
      </h1>
      <Reveal className="legal__notice">
        <p>
          Dieser Text ist ein Entwurf auf Basis der bestätigten Praxisangaben. Markierte Stellen müssen vor der
          Veröffentlichung durch die Praxis bzw. eine rechtliche Fachperson geprüft und ergänzt werden.
        </p>
      </Reveal>
      <div className="legal__body">{children}</div>
      <p>
        <a className="text-link" href="#start">
          <span className="link-underline">Zurück zur Startseite</span>
        </a>
      </p>
    </article>
  );
}

export function Impressum() {
  return (
    <LegalShell
      title="Impressum"
      italic="Angaben zur Praxis"
      meta={{
        title: `Impressum | ${PRACTICE.name} Zürich`,
        description: `Impressum der ${PRACTICE.name}, ${PRACTICE.doctor}, ${PRACTICE.street}, ${PRACTICE.zip} ${PRACTICE.city}.`,
      }}
    >
      <h2>Verantwortlich für den Inhalt</h2>
      <p>
        {PRACTICE.name}
        <br />
        {PRACTICE.doctor}
        <br />
        {PRACTICE.street}
        <br />
        {PRACTICE.zip} {PRACTICE.city}, {PRACTICE.country}
      </p>
      <p>
        Telefon: <a href={PRACTICE.phoneHref}>{PRACTICE.phoneDisplay}</a>
        <br />
        E-Mail: <a href={`mailto:${PRACTICE.email}`}>{PRACTICE.email}</a>
      </p>

      <h2>Berufsbezeichnung</h2>
      <p>{PRACTICE.title}</p>
      <p>
        <Todo>Verleihender Staat bzw. Anerkennung des Facharzttitels</Todo>
      </p>

      <h2>Rechtsform und Register</h2>
      <p>
        <Todo>Rechtsform der Praxis (z. B. Einzelunternehmen, GmbH, AG)</Todo>
        <br />
        <Todo>Unternehmens-Identifikationsnummer (UID), falls vorhanden</Todo>
        <br />
        <Todo>Handelsregistereintrag, falls vorhanden</Todo>
        <br />
        <Todo>Mehrwertsteuernummer, falls vorhanden</Todo>
      </p>

      <h2>Berufsrechtliche Angaben</h2>
      <p>
        <Todo>Zuständige Aufsichtsbehörde / Bewilligungsbehörde für die Berufsausübung</Todo>
        <br />
        <Todo>Mitgliedschaften (z. B. FMH, kantonale Ärztegesellschaft) – nur sofern bestätigt</Todo>
        <br />
        <Todo>GLN- bzw. ZSR-Nummer – nur falls veröffentlicht werden soll</Todo>
      </p>

      <h2>Haftungsausschluss</h2>
      <p>
        Die Inhalte dieser Website dienen der allgemeinen Information über die Praxis und ihr Leistungsangebot. Sie
        ersetzen keine persönliche ärztliche Beratung, Untersuchung oder Behandlung. Für Inhalte externer Websites,
        auf die verlinkt wird, sind ausschliesslich deren Betreiber verantwortlich.
      </p>

      <h2>Urheberrecht und Bildnachweise</h2>
      <p>
        Die Inhalte und Gestaltung dieser Website sind urheberrechtlich geschützt.{' '}
        <Todo>Bildnachweise ergänzen, sobald freigegebene Fotografien eingesetzt werden</Todo>
      </p>

      <h2>Konzept, Design und Umsetzung</h2>
      <p>Peakvio</p>
    </LegalShell>
  );
}

export function Datenschutz() {
  return (
    <LegalShell
      title="Datenschutz"
      italic="erklärung"
      meta={{
        title: `Datenschutzerklärung | ${PRACTICE.name} Zürich`,
        description: `Informationen zum Umgang mit Personendaten auf der Website der ${PRACTICE.name} in Zürich.`,
      }}
    >
      <p>
        Der Schutz Ihrer Personendaten ist uns wichtig. Diese Datenschutzerklärung informiert darüber, welche Daten
        beim Besuch dieser Website bearbeitet werden. Massgebend ist das Schweizer Bundesgesetz über den Datenschutz
        (DSG).
      </p>

      <h2>Verantwortliche Stelle</h2>
      <p>
        {PRACTICE.name}, {PRACTICE.doctor}
        <br />
        {PRACTICE.street}, {PRACTICE.zip} {PRACTICE.city}
        <br />
        E-Mail: <a href={`mailto:${PRACTICE.email}`}>{PRACTICE.email}</a> · Telefon:{' '}
        <a href={PRACTICE.phoneHref}>{PRACTICE.phoneDisplay}</a>
      </p>

      <h2>Hosting und Server-Logfiles</h2>
      <p>
        Beim Aufruf der Website werden technisch notwendige Daten (z. B. IP-Adresse, Datum und Uhrzeit, aufgerufene
        Seite, Browsertyp) in Server-Logfiles verarbeitet, um den sicheren Betrieb zu gewährleisten.{' '}
        <Todo>Name und Standort des Hosting-Anbieters sowie Speicherdauer der Logfiles ergänzen</Todo>
      </p>

      <h2>Keine Cookies, kein Tracking</h2>
      <p>
        Diese Website verwendet in der vorliegenden Fassung keine Cookies zu Analyse- oder Marketingzwecken und keine
        Tracking-Dienste. Schriften werden lokal vom eigenen Server geladen; dabei werden keine Daten an Dritte
        übermittelt.
      </p>

      <h2>Kartendarstellung (Google Maps)</h2>
      <p>
        Die interaktive Karte wird erst geladen, wenn Sie dies aktiv auswählen. Erst dann werden Daten – insbesondere
        Ihre IP-Adresse – an Google übermittelt, wobei eine Bearbeitung auch ausserhalb der Schweiz (z. B. in den USA)
        möglich ist. Der Link zur Routenplanung öffnet die Website von Google in einem neuen Tab.
      </p>

      <h2>Online-Terminbuchung (Doctena)</h2>
      <p>
        Für die Online-Terminbuchung werden Sie auf die Plattform Doctena weitergeleitet. Auf dieser Website selbst
        werden keine Termin- oder Gesundheitsdaten erhoben. Für die Datenbearbeitung bei der Buchung gelten die
        Datenschutzbestimmungen von Doctena.
      </p>

      <h2>Kontaktaufnahme per E-Mail oder Telefon</h2>
      <p>
        Wenn Sie die Praxis kontaktieren, werden Ihre Angaben zur Bearbeitung der Anfrage verwendet und unterliegen dem
        ärztlichen Berufsgeheimnis. Bitte beachten Sie, dass unverschlüsselte E-Mails nicht vollständig vor dem Zugriff
        Dritter geschützt sind. Teilen Sie sensible Gesundheitsinformationen daher bevorzugt telefonisch oder
        persönlich mit.
      </p>

      <h2>Ihre Rechte</h2>
      <p>
        Sie haben im Rahmen des anwendbaren Rechts das Recht auf Auskunft, Berichtigung, Löschung sowie Einschränkung
        der Bearbeitung Ihrer Personendaten. Wenden Sie sich dazu an die oben genannte verantwortliche Stelle.
      </p>

      <h2>Änderungen</h2>
      <p>
        Diese Datenschutzerklärung kann angepasst werden. Es gilt die jeweils auf dieser Website veröffentlichte
        Fassung. <Todo>Stand / Datum der Fassung ergänzen</Todo>
      </p>
    </LegalShell>
  );
}
