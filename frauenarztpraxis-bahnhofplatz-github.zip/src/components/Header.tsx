import { AnimatePresence, motion, useMotionValueEvent, useScroll } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import { NAV, PRACTICE } from '../data/practice';
import { EASE, ExternalHint } from './motion';

export function Header({ onHome }: { onHome: boolean }) {
  const { scrollY } = useScroll();
  const [solid, setSolid] = useState(false);
  const [open, setOpen] = useState(false);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useMotionValueEvent(scrollY, 'change', (v) => setSolid(v > 40));
  useEffect(() => setSolid(window.scrollY > 40), []);

  useEffect(() => {
    if (!open) return;
    document.documentElement.classList.add('no-scroll');
    const first = panelRef.current?.querySelector<HTMLElement>('a');
    first?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
        toggleRef.current?.focus();
      }
      if (e.key === 'Tab' && panelRef.current) {
        const items = Array.from(panelRef.current.querySelectorAll<HTMLElement>('a, button'));
        const all = [toggleRef.current!, ...items];
        const idx = all.indexOf(document.activeElement as HTMLElement);
        if (e.shiftKey && idx <= 0) {
          e.preventDefault();
          all[all.length - 1].focus();
        } else if (!e.shiftKey && idx === all.length - 1) {
          e.preventDefault();
          all[0].focus();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.documentElement.classList.remove('no-scroll');
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const href = (h: string) => h;

  return (
    <header className={`header ${solid || !onHome ? 'header--solid' : ''} ${open ? 'header--open' : ''}`}>
      <div className="header__inner">
        <a className="brand" href={href('#start')} aria-label={`${PRACTICE.name} – zur Startseite`}>
          <span className="brand__name">
            Frauenarztpraxis <em>Bahnhofplatz</em>
          </span>
          <span className="brand__doc">{PRACTICE.doctor}</span>
        </a>

        <nav className="nav" aria-label="Hauptnavigation">
          <ul>
            {NAV.map((n) => (
              <li key={n.href}>
                <a className="link-underline" href={href(n.href)}>
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <a className="btn btn--primary btn--sm header__cta" href={PRACTICE.booking} target="_blank" rel="noopener">
          <span>Termin vereinbaren</span>
          <ExternalHint />
        </a>

        <button
          ref={toggleRef}
          type="button"
          className="menu-toggle"
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((o) => !o)}
        >
          <span className="sr-only">{open ? 'Menü schliessen' : 'Menü öffnen'}</span>
          <span className="menu-toggle__bar" aria-hidden="true" />
          <span className="menu-toggle__bar" aria-hidden="true" />
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            ref={panelRef}
            className="mobile-menu"
            role="dialog"
            aria-modal="true"
            aria-label="Navigation"
            initial={{ clipPath: 'circle(0% at calc(100% - 40px) 40px)' }}
            animate={{ clipPath: 'circle(150% at calc(100% - 40px) 40px)' }}
            exit={{ clipPath: 'circle(0% at calc(100% - 40px) 40px)' }}
            transition={{ duration: 0.8, ease: EASE }}
          >
            <svg className="mobile-menu__line" viewBox="0 0 400 800" aria-hidden="true">
              <motion.path
                d="M420,40 C260,120 380,300 220,380 C80,450 60,620 200,700 C260,734 300,780 280,840"
                fill="none"
                stroke="currentColor"
                strokeWidth="1"
                initial={{ pathLength: 0 } as never}
                animate={{ pathLength: 1 } as never}
                transition={{ duration: 1.8, delay: 0.2, ease: EASE }}
              />
            </svg>
            <ul className="mobile-menu__list">
              {NAV.map((n, i) => (
                <motion.li
                  key={n.href}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.15 + i * 0.07, duration: 0.8, ease: EASE }}
                >
                  <a href={href(n.href)} onClick={() => setOpen(false)}>
                    <span className="mobile-menu__no">0{i + 1}</span>
                    {n.label}
                  </a>
                </motion.li>
              ))}
            </ul>
            <motion.div
              className="mobile-menu__foot"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.55, duration: 0.6 }}
            >
              <a className="btn btn--primary btn--block" href={PRACTICE.booking} target="_blank" rel="noopener">
                <span>Termin online vereinbaren</span>
                <ExternalHint />
              </a>
              <a className="btn btn--ghost btn--block" href={PRACTICE.phoneHref}>
                <span>Anrufen · {PRACTICE.phoneDisplay}</span>
              </a>
              <p className="mobile-menu__addr">
                {PRACTICE.street}, {PRACTICE.zip} {PRACTICE.city}
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
