import { PRACTICE } from '../data/practice';
import { bloom } from '../art/paths';
import { Arrow, Breath, DrawMotif, ExternalHint, MaskLines, Reveal } from './motion';

export function Booking() {
  return (
    <section id="termin" className="booking" aria-labelledby="booking-title">
      <svg className="booking__edge" viewBox="0 0 1440 80" preserveAspectRatio="none" aria-hidden="true">
        <path d="M0,80 C320,10 620,10 860,40 C1080,68 1260,60 1440,20 L1440,0 L0,0 Z" />
      </svg>
      <Breath className="booking__breath booking__breath--a" />
      <Breath className="booking__breath booking__breath--b" />
      <DrawMotif
        className="booking__bloom"
        viewBox="0 0 400 400"
        paths={[...bloom(200, 200, 7, 180, 46, -90), ...bloom(200, 200, 7, 110, 30, -64)]}
        stagger={0.12}
        duration={2.6}
      />

      <div className="container booking__inner">
        <Reveal as="p" className="eyebrow eyebrow--light">Terminvereinbarung</Reveal>
        <h2 id="booking-title" className="display display--lg">
          <MaskLines lines={['Nehmen Sie sich Zeit', <em key="i">für Ihre Gesundheit.</em>]} />
        </h2>
        <Reveal as="p" className="lead" delay={0.15}>
          Vereinbaren Sie Ihren Termin bequem online oder kontaktieren Sie die Praxis telefonisch.
        </Reveal>
        <Reveal className="booking__ctas" delay={0.25}>
          <a className="btn btn--light" href={PRACTICE.booking} target="_blank" rel="noopener">
            <span>Online Termin vereinbaren</span>
            <Arrow />
            <ExternalHint />
          </a>
          <a className="btn btn--ghost-light" href={PRACTICE.phoneHref}>
            <span>
              <span className="sr-only">Anrufen: </span>
              {PRACTICE.phoneDisplay}
            </span>
          </a>
        </Reveal>
        <Reveal as="p" className="booking__hint" delay={0.35}>
          Die Online-Terminbuchung erfolgt über Doctena. Bitte beachten Sie die Datenschutzhinweise der Plattform.
        </Reveal>
      </div>
    </section>
  );
}
