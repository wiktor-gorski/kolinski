import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { ArtPanel } from '../art/ArtPanel';
import { SIGNATURE_LINE } from '../art/paths';
import { PRACTICE } from '../data/practice';
import { Arrow, Breath, DrawPath, EASE, ExternalHint, MaskLines, MaskReveal } from './motion';

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const artY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 90]);
  const textY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : -40]);

  const fade = (delay: number) => ({
    initial: { opacity: 0, y: reduce ? 0 : 18 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 1, delay, ease: EASE },
  });

  return (
    <section ref={ref} id="start" className="hero" aria-labelledby="hero-title">
      <Breath className="hero__breath hero__breath--a" />
      <Breath className="hero__breath hero__breath--b" />

      <div className="hero__grid container">
        <motion.div className="hero__text" style={{ y: textY }}>
          <motion.p className="eyebrow" {...fade(0.05)}>
            <span>
              Frauenarztpraxis Bahnhofplatz <span aria-hidden="true">·</span> Zürich
            </span>
          </motion.p>

          <h1 id="hero-title" className="display hero__title">
            <MaskLines
              inView={false}
              delay={0.15}
              stagger={0.16}
              lines={['Für jede Frau.', <em key="i">In jeder Lebensphase.</em>]}
            />
          </h1>

          <motion.p className="lead hero__lead" {...fade(0.65)}>
            Persönliche gynäkologische Betreuung, langjährige medizinische Erfahrung und Raum für Ihre
            individuellen Anliegen – mitten im Herzen von Zürich.
          </motion.p>

          <motion.div className="hero__ctas" {...fade(0.8)}>
            <a className="btn btn--primary" href={PRACTICE.booking} target="_blank" rel="noopener">
              <span>Termin vereinbaren</span>
              <Arrow />
              <ExternalHint />
            </a>
            <a className="text-link" href="#aerztin">
              <span className="link-underline">Die Ärztin kennenlernen</span>
              <Arrow />
            </a>
          </motion.div>

          <motion.ul className="trust-row" aria-label="Auf einen Blick" {...fade(1)}>
            <li>Fachärztin FMH</li>
            <li>Langjährige Erfahrung</li>
            <li>Direkt am Zürich Hauptbahnhof</li>
          </motion.ul>
        </motion.div>

        <motion.div className="hero__visual" style={{ y: artY }}>
          <MaskReveal className="hero__frame" immediate delay={0.25}>
            <ArtPanel tone="sand" motif={1} immediate delay={1} className="hero__art" />
          </MaskReveal>
          <p className="hero__caption">
            <span>Bahnhofplatz 4</span>
            <span aria-hidden="true" className="hero__caption-rule" />
            <span>8001 Zürich</span>
          </p>
          <MaskReveal className="hero__frame-small" immediate delay={0.7} from="left">
            <ArtPanel tone="rose" motif={4} immediate delay={1.5} />
          </MaskReveal>
        </motion.div>
      </div>

      <svg className="hero__line" viewBox="0 0 1440 240" preserveAspectRatio="none" aria-hidden="true">
        <DrawPath d={SIGNATURE_LINE} immediate delay={0.9} duration={3.2} strokeWidth={1.1} />
      </svg>

      <motion.a
        href="#vertrauen"
        className="scroll-cue"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 1 }}
      >
        <span className="sr-only">Weiter zum Inhalt</span>
        <span className="scroll-cue__line" aria-hidden="true" />
      </motion.a>
    </section>
  );
}
