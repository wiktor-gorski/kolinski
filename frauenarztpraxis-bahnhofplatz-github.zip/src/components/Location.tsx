import { AnimatePresence, motion } from 'framer-motion';
import { useState } from 'react';
import { HOURS, PRACTICE } from '../data/practice';
import { Arrow, DrawPath, EASE, ExternalHint, MaskLines, Reveal } from './motion';

function todayInZurich(): number {
  const wd = new Intl.DateTimeFormat('en-US', { weekday: 'short', timeZone: 'Europe/Zurich' }).format(new Date());
  return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(wd);
}

export function OpeningHours({ compact = false }: { compact?: boolean }) {
  const today = todayInZurich();
  return (
    <dl className={`hours ${compact ? 'hours--compact' : ''}`}>
      {HOURS.map((h) => (
        <div key={h.day} className={`hours__row ${h.dow === today ? 'is-today' : ''}`}>
          <dt>
            {h.day}
            {h.dow === today && !compact && <span className="hours__today">Heute</span>}
          </dt>
          <dd>
            {h.slots.map((s) => (
              <span key={s}>{s}</span>
            ))}
          </dd>
        </div>
      ))}
    </dl>
  );
}

/** Datenschutzfreundliche Karte: Google Maps wird erst nach aktiver Zustimmung geladen. */
function ConsentMap() {
  const [load, setLoad] = useState(false);
  return (
    <div className="map">
      <AnimatePresence mode="wait">
        {!load ? (
          <motion.div
            key="static"
            className="map__static"
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: EASE }}
          >
            <svg className="map__drawing" viewBox="0 0 600 460" aria-hidden="true">
              {/* Schematische Darstellung – kein massstabsgetreuer Plan */}
              <DrawPath d="M-10,340 C120,300 220,330 330,300 C430,272 520,286 620,250" duration={2.4} />
              <DrawPath d="M-10,360 C120,320 220,350 330,320 C430,292 520,306 620,270" duration={2.4} delay={0.2} />
              <path className="map__block" d="M70,90 h250 v130 h-250 z" />
              <path className="map__block map__block--soft" d="M380,120 h150 v110 h-150 z" />
              <DrawPath d="M330,160 C350,150 362,150 380,160" duration={1.2} delay={1} />
            </svg>
            <span className="map__label map__label--hb">Hauptbahnhof Zürich</span>
            <span className="map__pin">
              <span className="map__pin-dot" aria-hidden="true" />
              <span className="map__pin-text">
                <strong>Bahnhofplatz 4</strong>
                <span>3. OG · Eingang beim Visilab</span>
              </span>
            </span>
            <div className="map__consent">
              <p>
                Beim Laden der Karte werden Daten an Google übertragen. Mehr dazu in der{' '}
                <a href="#/datenschutz" className="link-underline">
                  Datenschutzerklärung
                </a>
                .
              </p>
              <button type="button" className="btn btn--outline btn--sm" onClick={() => setLoad(true)}>
                Interaktive Karte laden
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.iframe
            key="map"
            className="map__iframe"
            title={`Karte: ${PRACTICE.name}, ${PRACTICE.street}, ${PRACTICE.zip} ${PRACTICE.city}`}
            src={PRACTICE.mapsEmbed}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export function Location() {
  return (
    <section id="kontakt" className="location section" aria-labelledby="location-title">
      <div className="container">
        <div className="location__head">
          <Reveal as="p" className="eyebrow">Standort und Kontakt</Reveal>
          <h2 id="location-title" className="display display--md">
            <MaskLines lines={['Mitten in Zürich.', <em key="i">Einfach erreichbar.</em>]} />
          </h2>
        </div>

        <div className="location__grid">
          <div className="location__info">
            <Reveal>
              <address className="location__address">
                <strong>{PRACTICE.name}</strong>
                <span>{PRACTICE.doctor}</span>
                <span>{PRACTICE.street}</span>
                <span>
                  {PRACTICE.zip} {PRACTICE.city}
                </span>
              </address>
              <p className="location__access">
                Dritter Stock, Eingang beim Visilab.
                <br />
                Direkt gegenüber dem Hauptbahnhof Zürich.
              </p>
            </Reveal>

            <Reveal className="contact-lines" delay={0.1}>
              <a className="contact-line" href={PRACTICE.phoneHref}>
                <span className="contact-line__k">Telefon</span>
                <span className="contact-line__v link-underline">{PRACTICE.phoneDisplay}</span>
              </a>
              <a className="contact-line" href={`mailto:${PRACTICE.email}`}>
                <span className="contact-line__k">E-Mail</span>
                <span className="contact-line__v link-underline">{PRACTICE.email}</span>
              </a>
              <a className="contact-line" href={PRACTICE.mapsRoute} target="_blank" rel="noopener">
                <span className="contact-line__k">Route</span>
                <span className="contact-line__v link-underline">In Google Maps planen</span>
                <ExternalHint />
              </a>
            </Reveal>

            <Reveal className="location__hours" delay={0.15}>
              <h3 className="mini-title">Öffnungszeiten</h3>
              <OpeningHours />
            </Reveal>

            <Reveal className="location__transit" delay={0.2}>
              <h3 className="mini-title">Anreise mit öffentlichen Verkehrsmitteln</h3>
              <p>
                Die Praxis liegt direkt gegenüber dem Hauptbahnhof Zürich und ist mit Zug, Tram und Bus bequem
                erreichbar. Vom Hauptbahnhof sind es nur wenige Schritte über den Bahnhofplatz bis zum Eingang beim
                Visilab.
              </p>
              <a className="text-link" href="https://www.sbb.ch/de" target="_blank" rel="noopener">
                <span className="link-underline">Verbindung auf sbb.ch suchen</span>
                <Arrow />
                <ExternalHint />
              </a>
            </Reveal>
          </div>

          <Reveal className="location__map" delay={0.1}>
            <ConsentMap />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
