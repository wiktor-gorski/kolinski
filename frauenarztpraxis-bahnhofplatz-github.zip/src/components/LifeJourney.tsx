import { AnimatePresence, motion, useReducedMotion, useScroll, useSpring } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';
import { ArtPanel, type Tone } from '../art/ArtPanel';
import { JOURNEY_LINE, MOTIFS } from '../art/paths';
import { PHASES } from '../data/practice';
import { Arrow, DrawMotif, DrawPath, EASE, MaskLines, Reveal } from './motion';

const TONES: Tone[] = ['ivory', 'sand', 'rose', 'dusk', 'sand'];
/** Positionen der Knotenpunkte entlang der Lebenslinie (in % der Höhe). */
const NODES = [0.1, 0.3, 0.5, 0.7, 0.9];

export function LifeJourney() {
  const bodyRef = useRef<HTMLDivElement>(null);
  const itemRefs = useRef<(HTMLLIElement | null)[]>([]);
  const [active, setActive] = useState(0);
  const reduce = useReducedMotion();

  const { scrollYProgress } = useScroll({ target: bodyRef, offset: ['start 60%', 'end 70%'] });
  const progress = useSpring(scrollYProgress, { stiffness: 60, damping: 22, restDelta: 0.001 });

  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(Number((e.target as HTMLElement).dataset.index));
        });
      },
      { rootMargin: '-45% 0px -45% 0px' },
    );
    itemRefs.current.forEach((el) => el && io.observe(el));
    return () => io.disconnect();
  }, []);

  const goTo = (i: number) => {
    itemRefs.current[i]?.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'center' });
  };

  return (
    <motion.section
      className="journey"
      aria-labelledby="journey-title"
      animate={{ backgroundColor: PHASES[active].tint }}
      transition={{ duration: 1.4, ease: EASE }}
    >
      <div className="container journey__head">
        <Reveal as="p" className="eyebrow">Ein Leben. Viele Phasen.</Reveal>
        <h2 id="journey-title" className="display display--lg">
          <MaskLines lines={['Das Leben verändert sich.', <em key="i">Ihre Gesundheit bleibt wichtig.</em>]} />
        </h2>
        <Reveal as="p" className="journey__note" delay={0.2}>
          Jeder Lebensweg ist individuell. Die folgenden Phasen dienen der Orientierung – sie beschreiben keinen
          Weg, den jede Frau gehen muss, und Themen dürfen sich jederzeit überschneiden.
        </Reveal>
      </div>

      <div ref={bodyRef} className="container journey__body">
        {/* Sticky-Bühne (Desktop) */}
        <div className="journey__stage" aria-hidden="true">
          <div className="journey__stage-inner">
            <div className="journey__rail">
              <svg viewBox="0 0 200 1000" preserveAspectRatio="none" className="journey__rail-svg">
                <path d={JOURNEY_LINE} className="journey__rail-ghost" vectorEffect="non-scaling-stroke" />
                <DrawPath d={JOURNEY_LINE} progress={progress} strokeWidth={1.4} />
              </svg>
              {NODES.map((pos, i) => (
                <span
                  key={i}
                  className={`journey__node ${i <= active ? 'is-reached' : ''} ${i === active ? 'is-active' : ''}`}
                  style={{ top: `${pos * 100}%` }}
                >
                  {PHASES[i].no}
                </span>
              ))}
            </div>

            <div className="journey__frame">
              {PHASES.map((p, i) => (
                <motion.div
                  key={p.no}
                  className="journey__panel"
                  initial={false}
                  animate={{
                    clipPath:
                      i === active
                        ? 'inset(0% 0% 0% 0%)'
                        : i < active
                          ? 'inset(0% 0% 100% 0%)'
                          : 'inset(100% 0% 0% 0%)',
                    scale: i === active ? 1 : 1.08,
                  }}
                  transition={{ duration: reduce ? 0 : 1.3, ease: EASE }}
                >
                  <ArtPanel tone={TONES[i]} />
                </motion.div>
              ))}
              <AnimatePresence mode="wait">
                <motion.div
                  key={active}
                  className={`journey__motif ${TONES[active] === 'dusk' ? 'is-light' : ''}`}
                  initial={{ opacity: 1 }}
                  exit={{ opacity: 0, transition: { duration: 0.35 } }}
                >
                  <DrawMotif paths={MOTIFS[active]} immediate delay={0.35} stagger={0.15} duration={1.8} />
                </motion.div>
              </AnimatePresence>
              <AnimatePresence mode="wait">
                <motion.span
                  key={active}
                  className="journey__big-no"
                  initial={{ y: reduce ? 0 : 40, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: reduce ? 0 : -40, opacity: 0 }}
                  transition={{ duration: 0.7, ease: EASE }}
                >
                  {PHASES[active].no}
                </motion.span>
              </AnimatePresence>
            </div>
          </div>
        </div>

        {/* Inhalt – vollständig ohne Animation lesbar */}
        <ol className="journey__list">
          {PHASES.map((p, i) => (
            <li
              key={p.no}
              ref={(el) => {
                itemRefs.current[i] = el;
              }}
              data-index={i}
              className={`phase ${i === active ? 'is-active' : ''}`}
            >
              <div className="phase__mobile-art" aria-hidden="true">
                <ArtPanel tone={TONES[i]} motif={i} delay={0.1} />
              </div>
              <Reveal>
                <p className="phase__no">
                  <span>{p.no}</span>
                  <span className="phase__rule" aria-hidden="true" />
                  <span className="sr-only">von 05</span>
                </p>
                <h3 className="phase__title">
                  {p.title} <em>{p.italic}</em>
                </h3>
                <p className="phase__text">{p.text}</p>
                <ul className="phase__topics">
                  {p.topics.map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
                {i < PHASES.length - 1 && (
                  <button type="button" className="phase__next" onClick={() => goTo(i + 1)}>
                    <span className="link-underline">Weiter zu {PHASES[i + 1].no}</span>
                  </button>
                )}
              </Reveal>
            </li>
          ))}
        </ol>
      </div>

      <div className="container journey__foot">
        <Reveal as="p">
          <a className="text-link" href="#leistungen">
            <span className="link-underline">Alle Leistungen im Überblick</span>
            <Arrow />
          </a>
        </Reveal>
      </div>
    </motion.section>
  );
}
