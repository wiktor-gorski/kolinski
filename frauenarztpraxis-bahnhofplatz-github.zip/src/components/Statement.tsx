import { DrawPath, MaskLines, Parallax, Reveal } from './motion';

export function Statement() {
  return (
    <section id="vertrauen" className="statement section" aria-labelledby="statement-title">
      <Parallax className="statement__art" amount={40}>
        <svg viewBox="0 0 600 600" aria-hidden="true">
          <DrawPath
            d="M80,520 C40,360 140,200 300,180 C470,160 560,300 500,420 C450,520 300,540 240,440 C190,360 260,260 340,290 C400,312 400,390 350,400"
            duration={3.6}
          />
          <DrawPath d="M300,180 C290,120 310,70 340,40" duration={2} delay={1.6} />
        </svg>
      </Parallax>

      <div className="container statement__grid">
        <p className="eyebrow statement__eyebrow">Unser Verständnis</p>
        <h2 id="statement-title" className="display statement__title">
          <MaskLines
            lines={[
              <span key="a" className="statement__l1">Ihre Gesundheit.</span>,
              <span key="b" className="statement__l2">Ihre Fragen.</span>,
              <em key="c" className="statement__l3">Ihr Vertrauen.</em>,
            ]}
            stagger={0.18}
          />
        </h2>

        <div className="statement__body">
          <Reveal as="p" className="lead">
            Jede Frau hat ihre eigene Geschichte und individuelle gesundheitliche Bedürfnisse. Eine persönliche
            frauenärztliche Betreuung beginnt deshalb mit Zuhören, gegenseitigem Vertrauen und ausreichend Raum für
            Fragen.
          </Reveal>
          <Reveal as="p" delay={0.15}>
            Die Frauenarztpraxis Bahnhofplatz begleitet Frauen mit medizinischer Kompetenz durch unterschiedliche
            Lebensabschnitte.
          </Reveal>
        </div>
      </div>
    </section>
  );
}
