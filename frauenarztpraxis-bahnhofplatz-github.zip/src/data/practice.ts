/**
 * Zentrale, verifizierte Praxisdaten (NAP-konsistent).
 * Änderungen ausschliesslich nach Bestätigung durch die Praxis.
 */
export const PRACTICE = {
  name: 'Frauenarztpraxis Bahnhofplatz',
  doctor: 'Dr. med. Jolanda Kolinski',
  title: 'Fachärztin FMH für Gynäkologie und Geburtshilfe',
  street: 'Bahnhofplatz 4',
  zip: '8001',
  city: 'Zürich',
  country: 'Schweiz',
  floor: 'Drittes Obergeschoss',
  access: 'Zugang über Lift oder Treppenhaus',
  entrance: 'Eingang beim Visilab',
  landmark: 'Direkt gegenüber dem Hauptbahnhof Zürich',
  phoneDisplay: '044 955 30 00',
  phoneHref: 'tel:+41449553000',
  email: 'kontakt@frauenarztpraxis-bahnhofplatz.ch',
  website: 'https://frauenarztpraxis-bahnhofplatz.ch/',
  booking: 'https://www.doctena.ch/de/practitioner/DrmedJolandaKolinski',
  languages: ['Deutsch', 'Polnisch'],
  mapsRoute:
    'https://www.google.com/maps/dir/?api=1&destination=Bahnhofplatz%204%2C%208001%20Z%C3%BCrich',
  mapsEmbed:
    'https://www.google.com/maps?q=Bahnhofplatz%204%2C%208001%20Z%C3%BCrich&z=17&output=embed',
} as const;

export type Hours = { day: string; short: string; dow: number; slots: string[] };

/** dow: 0 = Sonntag … 6 = Samstag */
export const HOURS: Hours[] = [
  { day: 'Dienstag', short: 'Di', dow: 2, slots: ['07:30–12:00', '13:30–19:00'] },
  { day: 'Mittwoch', short: 'Mi', dow: 3, slots: ['07:30–12:00', '13:30–19:00'] },
  { day: 'Donnerstag', short: 'Do', dow: 4, slots: ['07:30–12:00'] },
  { day: 'Freitag', short: 'Fr', dow: 5, slots: ['07:30–12:00', '13:00–15:00'] },
];

export const NAV = [
  { href: '#start', label: 'Startseite' },
  { href: '#aerztin', label: 'Über die Ärztin' },
  { href: '#leistungen', label: 'Leistungen' },
  { href: '#praxis', label: 'Die Praxis' },
  { href: '#kontakt', label: 'Kontakt' },
] as const;

export type Phase = {
  no: string;
  title: string;
  italic: string;
  text: string;
  topics: string[];
  tint: string;
};

export const PHASES: Phase[] = [
  {
    no: '01',
    title: 'Erwachsen',
    italic: 'werden',
    text: 'Die ersten Fragen zum eigenen Körper verdienen Antworten in einer ruhigen, vertraulichen Atmosphäre – ohne Zeitdruck und in einer verständlichen Sprache.',
    topics: ['Mädchensprechstunde', 'Erste gynäkologische Fragen', 'Impfberatung'],
    tint: '#F7F3ED',
  },
  {
    no: '02',
    title: 'Im eigenen Körper',
    italic: 'zu Hause',
    text: 'Regelmässige Vorsorge schafft Sicherheit. Gleichzeitig ist Raum für individuelle Beschwerden und alles, was Sie persönlich beschäftigt.',
    topics: ['Gynäkologische Vorsorge', 'Jahreskontrollen', 'Hormonelle Gesundheit', 'Individuelle Beschwerden'],
    tint: '#F3EBE3',
  },
  {
    no: '03',
    title: 'Familien',
    italic: 'planung',
    text: 'Ob und wann eine Familie entsteht, ist eine sehr persönliche Frage. Die Praxis berät vertraulich, sachlich und wertfrei.',
    topics: ['Kinderwunschberatung', 'Sterilitätsabklärung'],
    tint: '#EFE2DA',
  },
  {
    no: '04',
    title: 'Schwangerschaft',
    italic: 'und Mutterschaft',
    text: 'Eine Zeit voller Veränderungen. Eine aufmerksame Begleitung – von der Vorsorge bis in die ersten Wochen nach der Geburt.',
    topics: ['Schwangerschaftsvorsorge', 'Pränatale Diagnostik', 'Betreuung nach der Geburt', 'Stillprobleme'],
    tint: '#EADBD3',
  },
  {
    no: '05',
    title: 'Eine neue',
    italic: 'Lebensphase',
    text: 'Hormonelle Veränderungen gehören zum Leben. Gemeinsam lassen sich Beschwerden einordnen und passende Wege finden.',
    topics: ['Menopauseberatung', 'Wechseljahrsbeschwerden', 'Hormonelle Veränderungen'],
    tint: '#F2EAE2',
  },
];

export type ServiceGroup = { title: string; italic?: string; intro: string; items: string[]; art: number };

export const SERVICES: ServiceGroup[] = [
  {
    title: 'Gynäkologie',
    intro: 'Vorsorge, Untersuchung und Beratung – von der ersten Sprechstunde bis zur regelmässigen Jahreskontrolle.',
    items: [
      'Gynäkologische Vorsorge',
      'Jahreskontrollen',
      'Gynäkologische Untersuchungen',
      'Senologie und Brustdiagnostik',
      'Mädchensprechstunde',
      'Impfberatung',
    ],
    art: 1,
  },
  {
    title: 'Hormonelle',
    italic: 'Gesundheit',
    intro: 'Abklärung und Begleitung bei hormonellen Veränderungen – individuell und in Ruhe besprochen.',
    items: [
      'Hormonelle Störungen',
      'Menopauseberatung',
      'Abklärung und Behandlung von Wechseljahrsbeschwerden',
      'Hormonersatztherapie',
      'Alternative Therapieansätze',
      'Abklärung urogynäkologischer Blasenbeschwerden',
    ],
    art: 4,
  },
  {
    title: 'Kinderwunsch',
    italic: 'und Familienplanung',
    intro: 'Beratung und Abklärung rund um Kinderwunsch und Familienplanung – vertraulich und wertfrei.',
    items: ['Kinderwunschberatung', 'Sterilitätsabklärung', 'Schwangerschaftsabbruch und Nachsorge'],
    art: 2,
  },
  {
    title: 'Schwangerschaft',
    italic: 'und Geburtshilfe',
    intro: 'Aufmerksame Begleitung durch die Schwangerschaft und die Zeit nach der Geburt.',
    items: [
      'Mutterschaftsvorsorge',
      'Schwangerschaftskontrollen',
      'Schwangerschaftsberatung',
      'Pränatale genetische Beratung',
      'Pränatale Ultraschalldiagnostik',
      'Geburtsnachkontrolle',
      'Beratung bei Stillproblemen',
    ],
    art: 3,
  },
];
