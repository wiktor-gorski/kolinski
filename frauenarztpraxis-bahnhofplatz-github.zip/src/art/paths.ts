/**
 * Generative Linien-Geometrie für das Signature-System.
 * Alle Illustrationen basieren auf derselben Blütenblatt-Formel,
 * damit Hero, Lebensphasen, Leistungen und Footer eine Familie bilden.
 */

/** Ein Blütenblatt als geschlossene Bézierform, ausgehend von (cx, cy). */
export function petal(cx: number, cy: number, len: number, width: number, angleDeg: number): string {
  const a = (angleDeg * Math.PI) / 180;
  const ux = Math.cos(a);
  const uy = Math.sin(a);
  const px = -uy;
  const py = ux;
  const tip = [cx + ux * len, cy + uy * len];
  const c1 = [cx + ux * len * 0.25 + px * width, cy + uy * len * 0.25 + py * width];
  const c2 = [cx + ux * len * 0.8 + px * width * 0.75, cy + uy * len * 0.8 + py * width * 0.75];
  const c3 = [cx + ux * len * 0.8 - px * width * 0.75, cy + uy * len * 0.8 - py * width * 0.75];
  const c4 = [cx + ux * len * 0.25 - px * width, cy + uy * len * 0.25 - py * width];
  const f = (n: number) => n.toFixed(1);
  return `M${f(cx)},${f(cy)} C${f(c1[0])},${f(c1[1])} ${f(c2[0])},${f(c2[1])} ${f(tip[0])},${f(tip[1])} C${f(c3[0])},${f(c3[1])} ${f(c4[0])},${f(c4[1])} ${f(cx)},${f(cy)}`;
}

export function bloom(cx: number, cy: number, n: number, len: number, width: number, rot = 0): string[] {
  return Array.from({ length: n }, (_, i) => petal(cx, cy, len, width, rot + (360 / n) * i));
}

export function circle(cx: number, cy: number, r: number): string {
  return `M${cx - r},${cy} a${r},${r} 0 1,0 ${r * 2},0 a${r},${r} 0 1,0 ${-r * 2},0`;
}

/**
 * Fünf Motive für die Lebensphasen / Leistungen (ViewBox 400 × 500).
 * Bewusst abstrakt: Knospe, offene Blüte, Verbindung, Geborgenheit, Samenstand.
 */
export const MOTIFS: string[][] = [
  // 0 · Knospe – Erwachsen werden
  [
    'M200,470 C196,400 206,340 200,280',
    petal(200, 285, 120, 34, -90),
    petal(200, 290, 96, 30, -112),
    petal(200, 290, 96, 30, -68),
    'M200,410 C170,392 146,370 136,336 C168,346 190,368 200,400',
  ],
  // 1 · Offene Blüte – Im eigenen Körper zu Hause
  [
    ...bloom(200, 230, 5, 120, 46, -90),
    circle(200, 230, 16),
    'M200,250 C204,330 194,400 200,480',
  ],
  // 2 · Verbindung – Familienplanung
  [
    circle(168, 230, 92),
    circle(236, 262, 92),
    'M60,420 C140,380 260,440 340,390',
    petal(200, 246, 40, 14, -90),
  ],
  // 3 · Geborgenheit – Schwangerschaft und Mutterschaft
  [
    'M200,80 C300,110 336,220 312,320 C292,402 240,450 200,456 C160,450 108,402 88,320 C64,220 100,110 200,80',
    'M200,140 C262,160 284,232 268,298 C254,352 226,382 200,386 C174,382 146,352 132,298 C116,232 138,160 200,140',
    circle(200, 280, 36),
    circle(200, 280, 6),
  ],
  // 4 · Samenstand – Eine neue Lebensphase
  [
    ...bloom(200, 220, 9, 96, 18, -90),
    circle(200, 220, 24),
    'M200,244 C190,320 214,392 200,480',
    'M200,380 C232,360 262,362 290,340 C258,330 226,350 200,372',
  ],
];

/** Die lange Signature-Linie (ViewBox 1440 × 240) – mit einer kleinen Schlaufe als Zeichen der Fürsorge. */
export const SIGNATURE_LINE =
  'M-20,150 C140,70 280,210 450,150 S720,40 860,120 C930,160 990,140 1010,100 C1030,56 980,40 960,76 C940,112 1000,150 1080,140 C1220,124 1300,60 1460,100';

/** Vertikale Lebenslinie (ViewBox 200 × 1000) */
export const JOURNEY_LINE =
  'M100,0 C40,80 160,140 100,200 C40,260 40,330 100,400 C170,470 150,540 100,600 C50,660 60,740 100,800 C150,860 140,940 100,1000';
