import type { CSSProperties, ReactNode } from 'react';
import { DrawMotif } from '../components/motion';
import { MOTIFS } from './paths';

export type Tone = 'sand' | 'rose' | 'ivory' | 'dusk' | 'bordeaux';

/**
 * Abstrakte Editorial-Bildfläche: warmes Licht, Körnung und eine Linienzeichnung.
 * Ersetzt Fotografie dort, wo (noch) keine freigegebenen Originalaufnahmen vorliegen –
 * bewusst als Kunstwerk erkennbar, nie als vermeintliches Praxisfoto.
 */
export function ArtPanel({
  tone = 'sand',
  motif,
  className,
  style,
  immediate,
  delay = 0.3,
  children,
  placeholder,
}: {
  tone?: Tone;
  motif?: number;
  className?: string;
  style?: CSSProperties;
  immediate?: boolean;
  delay?: number;
  children?: ReactNode;
  /** Sichtbarer Hinweis auf einen vorgesehenen Bildplatz für authentische Fotografie. */
  placeholder?: string;
}) {
  return (
    <div className={`art art--${tone} ${className ?? ''}`} style={style}>
      <span className="art__light art__light--a" aria-hidden="true" />
      <span className="art__light art__light--b" aria-hidden="true" />
      <span className="art__grain" aria-hidden="true" />
      {motif !== undefined && (
        <DrawMotif className="art__motif" paths={MOTIFS[motif]} immediate={immediate} delay={delay} />
      )}
      {children}
      {placeholder && (
        <span className="art__placeholder">
          <span className="art__placeholder-dot" aria-hidden="true" />
          {placeholder}
        </span>
      )}
    </div>
  );
}
