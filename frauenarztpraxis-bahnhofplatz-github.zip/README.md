# Frauenarztpraxis Bahnhofplatz – Website-Entwurf (Peakvio)

Designkonzept *The Art of Women's Health*. React 18 · TypeScript · Vite · Framer Motion.

```bash
npm install
npm run dev       # Entwicklung
npm run build     # Produktions-Build nach dist/
npm run preview   # Build lokal ansehen
```

## Struktur

| Pfad | Inhalt |
| --- | --- |
| `src/data/practice.ts` | **Einzige Quelle** aller Praxisdaten (NAP, Öffnungszeiten, Lebensphasen, Leistungen) |
| `src/art/paths.ts` | Generative Linien-Geometrie (Blütenblatt-Formel, Signature-Linie, Lebenslinie) |
| `src/art/ArtPanel.tsx` | Abstrakte Bildflächen inkl. sichtbarer Bildplatz-Kennzeichnung |
| `src/components/motion.tsx` | Motion-System: MaskLines, DrawPath/DrawMotif, MaskReveal, Parallax, Breath |
| `src/components/*` | Sektionen: Header, Hero, Statement, Doctor, LifeJourney, Services, Trust, Practice, Booking, Location, Footer, MobileBar, Legal |
| `index.html` | Meta-Titel/-Beschreibung, Open Graph, JSON-LD (MedicalClinic + Physician), `noindex` |

## Vor dem Go-live – offene Punkte

1. **Fotografie:** Alle Bildflächen sind abstrakte Kunstflächen. Bildplätze für ein authentisches Portrait von Dr. Kolinski und Praxisaufnahmen sind sichtbar gekennzeichnet („Bildplatz … nach Freigabe“). Nach Freigabe der Fotos als AVIF/WebP in `ArtPanel` bzw. die Bildplätze einsetzen und die Platzhalter-Hinweise entfernen.
2. **Impressum / Datenschutz:** Entwürfe unter `#/impressum` und `#/datenschutz`. Mit „Zur Prüfung“ markierte Angaben (Rechtsform, UID, Aufsichtsbehörde, Hosting-Anbieter, Stand usw.) müssen von der Praxis ergänzt und rechtlich geprüft werden.
3. **Doctena-Angabe „mehr als 330 Empfehlungen“:** vor Veröffentlichung gegen das aktuelle Profil prüfen.
4. **Indexierung freischalten:** In `index.html` das `<meta name="robots" content="noindex, …">` entfernen und `public/robots.txt` auf `Allow: /` umstellen.

## Geschützte Bereitstellung (Entwurf)

Der Entwurf steht auf `noindex` und `robots.txt: Disallow`. Zusätzlich mit Passwort ausliefern, z. B.:

- **Netlify / Vercel:** Passwortschutz (Site Protection / Deployment Protection) aktivieren.
- **Apache:** `.htaccess` mit `AuthType Basic` + `.htpasswd` und `Header set X-Robots-Tag "noindex, nofollow"`.
- **Nginx:** `auth_basic` + `add_header X-Robots-Tag "noindex, nofollow";`

## Datenschutz & Barrierefreiheit (umgesetzt)

- Schriften selbst gehostet (keine Google-Fonts-Anfragen), keine Cookies, kein Tracking.
- Google Maps lädt erst nach aktivem Klick (Zwei-Klick-Lösung); vorher statische, schematische Darstellung.
- Keine Formulare, keine Erhebung von Gesundheitsdaten; Buchung ausschliesslich über Doctena.
- Skip-Link, sichtbare Fokuszustände, Tastaturbedienung (inkl. Fokusfalle und Escape im mobilen Menü), ARIA-Akkordeon, `prefers-reduced-motion` wird respektiert.
- Kleine Schrift nur in AA-konformen Farben (Espresso, Bordeaux, `--rose-ink`); Dusty Rose ausschliesslich dekorativ.
